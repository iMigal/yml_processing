<?php
  if($file) {
    echo "<a href=\"?page=imports&id={$file[3]}\"><div class=\"imports_message_danger\">
      Замечен сбой при обработке информации. Хотите возобновить работу?</div></a>";
  } else {
    echo "<div class=\"imports_message\">{$message}</div>";
  }
  foreach ($imports as $item) {
    echo "<a href=\"?page=imports&id={$item['id']}\"><div class=\"imports_link\">{$item['link']}</div></a>";
  }