<?php
  require_once('code.php');
  require_once('view.php');