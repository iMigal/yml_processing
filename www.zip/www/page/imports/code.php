<?php
  ini_set("max_execution_time", 300);
  $yml = NEW yml;
  $check_params = NEW check_params;

  $id = (isset($_GET['id'])) ? $_GET['id'] : 0 ;
  $message = "Ссылка не выбрана";

  //Отработка при сбое
  $filename = "parse.txt"; $file = 0;
  if(file_exists($filename)) {
    $txt = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $file = explode(";", $txt[0]);
  }
  if($id) {
    $fRec = 0; $fCat = 1;
    if(!$file) {
      if($id == $file[3]){
        $id = $file[3];
        $fRec = $file[1];
        $fCat = 0;
      }
    }
    $href = $db -> dbSELECT('*','imports','id ='.$id);
    $fields = preg_split("/[\s,]+/", $href[0]['fields']);
    $data = $yml -> yml_parse($href[0]['link'],$fields);
    //Добавляем категории
    $category = $db -> dbSELECT('*','category','','id DESC');
    $catIndex = array();
    $catString = '';
    foreach ($category as $item){
      $catString .= $item['name'].',';
      array_push($catIndex, $item['name']);
    }
    if($fCat) {
      $idCat = $category[0]['id'] + 1;
      $nextid = $category[0]['id'] + 1;
      $parent = array();
      $cat = array();
      foreach ($data['category'] as $item) {
        if(!stripos($catString,$item['name'])) {
          $category[$nextid]['id'] = $nextid;
          $category[$nextid]['name'] = $item['name'];
          $category[$nextid]['parent'] = $item['parent'];
          $catString .= $item['name'].',';
          array_push($catIndex, $item['name']);
          $nextid++;
        }
      }
      if($idCat != $nextid-1){
        $values = '';
        for($i = $idCat; $i<=$nextid-1; $i++) {
          $values .= "('{$category[$i]['name']}','{$data['category'][$category[$i]['parent']]['name']}'),";
        }
        $values[strlen($values)-1] = '';
        $db -> dbInsert("category","(name,parent) VALUES {$values};");
      }
    }

    //Добавляем записи
    $values = ""; $json = array(); $arr_str = '';$i = 0;
    foreach($data['offer'] as $key_p => $item) {
      $url = ''; $br = 1;
      if($i >= $fRec) {//Начинаем с записи на которой закончили
        $inInsert = '';
        $values = "(";
        foreach ($item as $key => $field) {
          if(in_array($key,$yml->fields_list())) {
            switch ($key) {
              case 'url':
                $val = $check_params->drop_simbols_in_href_get($field);
                $url = $val;
                $values .= "'{$val}',";
                break;
              case 'price':
                $val = $check_params->only_numbers_get($field);
                $values .= "{$val},";
                break;
              case 'currencyId':
                $val = htmlspecialchars($field, ENT_QUOTES);
                $values .= "'{$val}',";
                break;
              case 'categoryId':
                if(gettype($field) == "array") {
                  $val = array_search($data['category'][$field[0]]['name'], $catIndex);
                } else {
                  $val = array_search($data['category'][$field]['name'], $catIndex);
                }
                $values .= "'{$val}',";
                break;
              case 'picture':
                if(gettype($field) == "array") {
                  $val = htmlspecialchars($field[0], ENT_QUOTES);
                } else {
                  $val = htmlspecialchars($field, ENT_QUOTES);
                }
                $values .= "'{$val}',";
                break;
              case 'vendor':
                $val = htmlspecialchars($field, ENT_QUOTES);
                $values .= "'{$val}',";
                break;
              case 'name':
                $val = htmlspecialchars($field, ENT_QUOTES);
                $values .= "'{$val}',";
                break;
            }
            if($key == 'price') {
              if($db -> checkExistence("items","url='{$url}' AND price = {$val}")){ //Если уже сущетсвует URL с указанной ценой то пропускаем
                $br = 0;
                break;
              } elseif($db -> checkExistence("items","url='{$url}'")) {//Если уже сущетсвует URL, но цена поменялась обновляем цену
                $db -> dbUpdate("items","price = {$val}","url = '$url'");
                $i++;
                $fd = fopen($filename, 'w') or die("не удалось создать файл");
                $str = "rec;".$i.";".$url.";".$id;
                fwrite($fd, $str);
                fclose($fd);
                $br = 0;
                break;
              }
            }
            if(!stripos($inInsert,$key)) { $inInsert .= $key.","; }
          } else {
            $val = str_ireplace(array('"',"'"),"&#8216;",$field);
            $arr_str .= "{$key}:{$val},";
          }
        }
        if($br) {
          $arr_str[strlen($arr_str)-1] = '';
          $values .= " '[{$arr_str}]'),";
          $values[strlen($values)-1] = '';
          if(!$arr_str) {$inInsert[strlen($inInsert)-1] = '';} else {$inInsert .= "arr";}
          $db -> dbInsert("items","({$inInsert}) VALUES{$values}");//Если не сущ. URL в БД добавляем товар
          $i++;
          $fd = fopen($filename, 'w') or die("не удалось создать файл");
          $str = "rec;".$i.";".$url.";".$id;
          fwrite($fd, stripslashes($str));
          fclose($fd);
        }
      }
    }
    if(file_exists($filename)) {unlink($filename);}
    $message = "Обновилась информация по ссылке: ".$href[0]['link'];
  }
  $imports = $db -> dbSELECT('*','imports','','id DESC');