<?php
  $data = $db->dbSELECT("id,name,price,picture,vendor","items",$where,"id DESC",$offset,$limit);
  if(!$data && !empty($where) && $search){
    $data = $db->dbSELECT("id,name,price,picture,vendor","items",$where." OR arr LIKE '%$search%'","id DESC",$offset,$limit);
  }