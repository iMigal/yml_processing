<?php
  echo $forms->items($data);