<table class="items_view_table">
  <tr>
    <td class="items_view_img" valign="top"><img src="<?php echo $dataItem[0]['picture']; ?>"/><br/><b><?php echo $dataItem[0]['name']; ?></b></td>
    <td class="items_view_des" valign="top">
      <b>Стоимость: </b><?php echo $dataItem[0]['price']; ?>р.<br/>
      <?php if(!empty($model)) {?><b>Модель: </b><br /><?php echo $model."<br/>"; } ?>
      <b>Описание: </b><br /><?php echo $description; ?>
    </td>
  </tr>
  <tr>
    <td class="items_view_recom" colspan="2" valign="top"><h2>Возможно вам понравится</h2><?php echo $forms->items($recommendation); ?></td>
  </tr>
</table>