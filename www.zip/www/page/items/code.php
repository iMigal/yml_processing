<?php
  $id = $check_params->only_numbers_get($_GET['id']);
  $dataItem = $db->dbSELECT("*","items","id={$id}");
  $arr = breakArray2x($dataItem[0]['arr']);
  $description = $arr['description'];
  $model = (isset($arr['model'])) ? $arr['model'] : '';
  $recommendation = $db->dbSELECT("id,name,price,picture,vendor","items","categoryId = {$dataItem[0]['categoryId']} AND id <> {$id}",'price DESC','','9');
