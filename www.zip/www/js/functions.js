function sendRequest(url='',params='') { //AJAX
  if(url.length && params['page'].length) {
    let request = new XMLHttpRequest();
    let href = url + '?';
    for (const [key, value] of Object.entries(params)) {
      href = href + key + '=' + value + '&';
    }
    request.open('GET', href);
    request.send();

    request.onreadystatechange = function () {
      if (request.readyState == 4 && request.status == 200){
        document.getElementById(params['display_id']).innerHTML = request.responseText;
      }
    }
  } else {
    return 0;
  }
}

function category() {//Выводим подкатегории
  let parent = document.getElementById("category").value;
  sendRequest("use_ajax.php",{"page":"podCat","display_id":"podCat","parent":parent});
}

function pageGo(step) {//Постраничная навигация. Выводим записи со следующей страницы, предыдещей или страницы указанной в селекте
  let numPage = document.getElementById("numPage").value;
  let where = document.getElementById("where").value;
  switch (step) {
    case 'back':
      if(numPage>1) { document.getElementById("numPage").value = numPage-1; }
      break;
    case 'move':
      document.getElementById("numPage").value = numPage-0+1;
      break;
    case 'page':
      numPage = document.getElementById("page_select").value;
      document.getElementById("numPage").value = numPage;
      break;
  }
  sendRequest("use_ajax.php",{"page":"pageGo","display_id":"content_cont","step":step,"numPage":numPage,"where":where});
}

function search() {//Обновляем страницу с указанными параметрами при поиске
  let category = document.getElementById("category").value;
  let podCat = document.getElementById("podCat").value;
  let search = document.getElementById("search").value;
  document.location.href = "?page=index&category=" + category + "&podCat=" + podCat + "&search=" + search;
}
