﻿<?php
/***
 * FIle create for use AJAX
 * All function with AJAX you can find in /js/function.js
 */
  require_once('/classes/database.php');
  require_once('/classes/check_params.php');
  require_once('/classes/forms.php');

  $check_params = NEW check_params;
  require_once('config.php');
  $page = $check_params -> drop_simbols_get($_GET['page']);
  switch ($page) {
    case '':
      break;
    case 'podCat':
      $forms = NEW forms;
      $db = NEW database;
      $parent = $check_params->only_numbers_get($_GET['parent']);
      $data = $db->dbSELECT("id,name","category","parent = (SELECT name FROM category WHERE id={$parent})",'name ASC');
      $result = $forms->category_options($data,"Подкатегории");
      break;
    case 'pageGo':
      $forms = NEW forms;
      $db = NEW database;
      $step = $_GET['step'];
      switch ($step) {
        case 'back':
          $numPage = $check_params->only_numbers_get($_GET['numPage']) - 1;
          break;
        case 'move':
          $numPage = $check_params->only_numbers_get($_GET['numPage']) + 1;
          break;
        case 'page':
          $numPage = $check_params->only_numbers_get($_GET['numPage']);
          break;
      }

      $where = $_GET['where'];
      $offset = ($limit*($numPage-1)>0) ? $limit*($numPage-1) : '' ;
      include("page/index/index.php");
      break;
  }

  echo $result;
