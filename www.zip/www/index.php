﻿<?php
  require_once('/classes/database.php');
  require_once('/classes/check_params.php');
  require_once('/classes/forms.php');
  require_once('/classes/yml.php');
  require_once('/functions/arrays.php');

  $check_params = NEW check_params;
  $forms = NEW forms;
  $db = NEW database;

  if(isset($_GET['page'])) {
    $page = $check_params -> drop_simbols_get($_GET['page']);
  } else {
    $page = "index";
  }

  require_once('config.php');
?>
<html>
  <head>
    <title>Магазинчик</title>
    <link href="/style/style.css" rel="stylesheet" media="all">
    <script src="/js/functions.js"></script>
  </head>
  <body>
    <!--Блок справа "Главная"-->
    <a href="?page=index"><div id="main">Главная</div></a>
    <!--Блок справа "YML Обновление"-->
    <a href="?page=imports"><div id="yml">YML Обновление</div></a>
    <div class="main_cont"><!--Основной контейнер-->
      <div class="search_cont"><!--Контейнер с SELECT с категориями, полем INPUT и кнопкой для поиска-->
        <?php
          $cat_par = $db->dbSELECT("id,name","category","parent = ''",'name ASC');
          echo $forms -> category($cat_par,"Основная категория");
          $cat_par = array();
          echo $forms -> category($cat_par,"Подкатегория","podCat");
          echo $forms -> search("Поиск","Искать");
        ?>
      </div>
      <?php
        if(in_array($page, $display_numPage)) {
          $cPage = $db->countRecord("items",$where);
          echo $forms -> pageNum($cPage,$limit);
        }
      ?>
      <div class="content_cont" id="content_cont"><!--Контейнер для вывода основного контента-->
        <?php include("page/{$page}/index.php"); ?>
      </div>
    </div>
    <input type="hidden" name="numPage" id="numPage" value="<?php echo $numPage; ?>"/>
    <input type="hidden" name="where" id="where" value="<?php echo $where; ?>"/>
  </body>
</html>