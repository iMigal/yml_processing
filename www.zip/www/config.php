<?php
  $limit = 50;
  $numPage = (isset($_GET['numpage'])) ? $check_params->only_numbers_get($_GET['numpage']) : 1 ;
  $search = (isset($_GET['search'])) ? $check_params->drop_simbols_in_href_get($_GET['search']) : 0;
  $category = (isset($_GET['category'])) ? $check_params->only_numbers_get($_GET['category']) : 0;
  $podCat = (isset($_GET['podCat'])) ? $check_params->only_numbers_get($_GET['podCat']) : 0;

  $where = ""; $offset = "";
  if($numPage) {
    $offset = ($limit*($numPage-1)>0) ? $limit*($numPage-1) : '' ;
  }
  if($search) {
    $where .= "name LIKE '%{$search}%'";
  }
  if($category) {
    $where .= ($where) ? " AND" : "";
    $where .= ($podCat) ? "categoryId = {$podCat}" : "categoryId = {$category}";
  }

  $display_numPage = array("index");