<?php
/**
 * Class yml
 * Используется для обработки YML файлов
 *
 * Методы:
 *
 *  create_data($href)
 *    Видимость: private
 *    Входные параметры: строка - ссылка
 *    Возврат: Строку
 *    Действия: получаем код страницы
 *
 *  company_info(&$data)
 *    Видимость: private
 *    Входные параметры: XML
 *    Возврат: Массив
 *    Действия: Возвращает массив с данными о компании и дате создания YML документа
 *
 *  currency(&$data)
 *    Видимость: private
 *    Входные параметры: XML
 *    Возврат: Массив
 *    Действия: Возвращает данные по валюте
 *
 *  category(&$data)
 *    Видимость: private
 *    Входные параметры: XML
 *    Возврат: Массив
 *    Действия: Возвращаает категории
 *
 *  offer(&$data,$fields=array())
 *    Видимость: private
 *    Входные параметры: XML. массив - поля используемые в описании товара в YML файле
 *    Возврат: Массив
 *    Действия: Возвращает массив товарных позиций
 *
 *  yml_parse($href="",$fields=array())
 *    Видимость: public
 *    Входные параметры: строка - ссылка, масив - поля используемые в описании товара в YML файле
 *    Возврат: Массив
 *    Действия: Возвращает разобранный YML файл
 *
 *  fields_list()
 *    Видимость: public
 *    Входные параметры: НЕТ
 *    Возврат: массив
 *    Действия: возвращает массив fields
 */

class yml
{
  private $alphabet = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя";
  private $fields = array("url","price","currencyId","categoryId","name","picture","vendor");

  private function create_data($href) {
    $ch = curl_init($href);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HEADER, false);
    $data = curl_exec($ch);
    curl_close($ch);
    return (isset($data)) ? $data : 0;
  }

  private function company_info(&$data) {
    $result['date'] = strval($data->shop->date);
    $result['comp'] = strval($data->shop->url);
    return (isset($result)) ? $result : 0;
  }

  private function currency(&$data) {
    foreach ($data->shop->currencies->currency as $row) {
      $result[strval($row['id'])] = strval($row['rate']);
    }
    return (isset($result)) ? $result : 0;
  }

  private function category(&$data) {
    $i = 0;
    foreach ($data->shop->categories->category as $row) {
      $result[intval($row['id'])]['parent'] = intval($row['parentId']);
      $result[intval($row['id'])]['name'] = strval($row);
      $i++;
    }
    return (isset($result)) ? $result : 0;
  }

  private function offer(&$data,$fields=array()) {
    $i = 0;
    foreach ($data->shop->offers->offer as $row) {
      $arr = (array) $row;
      foreach ($fields as $field) {
        $result[$i][$field] = $arr[$field];
      }
      $i++;
    }
    return (isset($result)) ? $result : 0;
  }

  public function yml_parse($href="",$fields=array()) {
    $data = simplexml_load_string(str_ireplace("windows-1251","utf-8",iconv("windows-1251","utf-8", $this -> create_data($href))) );
    if(empty($data)) {return 0;}
    $result['company'] = $this -> company_info($data);
    $result['currency'] = $this -> currency($data);
    $result['category'] = $this -> category($data);
    $result['offer'] = $this -> offer($data,$fields);
    return $result;
  }

  public function fields_list() {
    return $this -> fields;
  }
}