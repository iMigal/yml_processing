<?php
/***
 * Class forms
 * Используется для выводжа различных форм и объектов
 *
 * Методы
 *
 *  search($placeholder = "",$value = "")
 *    Видимость: public
 *    Входные параметры: строка - placeholder в поле input, строка - надпись на кнопке
 *    Возврат: Строку
 *    Действия: Используется для вывода поиска.
 *
 *  category_options(&$data, $def="")
 *    Видимость: public
 *    Входные параметры: массив [id][name], строка - первое поле
 *    Возврат: Строку
 *    Действия: возвращает options для select
 *
 *  category(&$data, $def="", $onChange = "category")
 *    Видимость: public
 *    Входные параметры: массив [id][name], строка - первое поле, строка - функция для JS onChange
 *    Возврат: Строку
 *    Действия: Возвращает SELECT
 *
 *  one_item($data = array())
 *    Видимость: public
 *    Входные параметры: массив
 *    Возврат: Строку
 *    Действия: Возвращает блок товара
 *
 *  function items(&$data)
 *    Видимость: public
 *    Входные параметры: массив
 *    Возврат: Строку
 *    Действия: Возвращает групу товарных блоков
 *
 *  pageNum($cPage = 0,$limit = 50)
 *    Видимость: public
 *    Входные параметры: число - общее количество записей, число - количество записей на одной странице
 *    Возврат: Строку
 *    Действия: Возвращает html код навигации
 */

class forms
{
  public function search($placeholder = "",$value = "") {
    return "
      <input type=\"text\" name=\"search\" id=\"search\" placeholder=\"{$placeholder}\" class=\"input_search\"/>
      <input type=\"submit\" onClick=\"search()\" class=\"submit_search\" value=\"{$value}\"/>
    ";
  }

  public function category_options(&$data, $def="") {
    $result = "<option value=\"\" hidden disabled selected>{$def}</option>";
    if(!empty($data)) {
      foreach ($data as $item){
        $result .= "<option value=\"{$item['id']}\">{$item['name']}</option>";
      }
    }
    return $result;
  }

  public function category(&$data, $def="", $onChange = "category") {
    $result = $this->category_options($data,$def);
    $result = "<select class=\"select_category\" name=\"{$onChange}\" id=\"{$onChange}\" onChange=\"{$onChange}()\"> {$result} </select>";
    return $result;
  }

  public function one_item($data = array()) {
    $img  = (!empty($data['picture'])) ? $data['picture'] : "https://trenermozga.ru/wp-content/uploads/2019/03/1-4.png";
    $result = "
      <a href=\"?page=items&id={$data['id']}\">
        <div class=\"item_cont\">
          <div class=\"item_name\">{$data['name']}</div>
          <div class=\"item_vendor\">{$data['vendor']}</div>
          <div class=\"item_img\"><img src=\"{$img}\" alt=\"{$data['name']}\"/></div>
          <div class=\"item_price\">{$data['price']}р.</div>
          <div class=\"item_view\">Просмотр</div>
        </div>
      </a>";
    return $result;
  }

  public function items(&$data) {
    if(empty($data)) {return "Ни чего не найдено...";}
    $i = 0;
    $result = "<table class=\"item_table\">";
    foreach ($data as $item) {
      $i++;
      $item_fields['id'] = $item['id'];
      $item_fields['name'] = $item['name'];
      $item_fields['picture'] = $item['picture'];
      $item_fields['price'] = $item['price'];
      $item_fields['vendor'] = htmlspecialchars_decode($item['vendor']);
      if($i == 1) {$result .= "<tr><td>";}
      $result .= $this->one_item($item_fields);
      if($i == 3) {$result .= "</td></tr>"; $i=0;}
    }
    $result .= ($i!=0) ? "</td></tr>" : "" ;
    return $result."</table>";
  }

  public function pageNum($cPage = 0,$limit = 50) {
    $result = '';
    if($cPage>$limit) {
      $countPage = 0;
      if (($cPage % $limit) == 0) {
        $countPage = $cPage/$limit;
      } else {
        $countPage = floor($cPage/$limit) + 1;
      }
      $result .= "<div class=\"content_numPage\">";
      $result .= "<div class=\"page_num\"onClick=\"pageGo('back')\">Предыдущая</div>";
      $result .= "<select class=\"page_select\" name=\"page_select\" id=\"page_select\" onChange=\"pageGo('page')\">";
      $result .= "<option value=\"\" disabled selected>Перейти на страницу</option>";
      for($i= 1; $i<=$countPage;$i++) {
        $result .= "<option value=\"{$i}\">{$i}</option>";
      }
      $result .= "</select>";
      $result .= "<div class=\"page_num\"onClick=\"pageGo('move')\">Следующая</div>";
      $result .= "</div>";
    }
    return $result;
  }
}