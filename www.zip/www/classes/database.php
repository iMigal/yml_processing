<?php
/**
 * Class database
 * Используется для работы с базой данных. Также в данном классе указзываются данные для подключения к БД
 *
 *
 * Методы классе:
 *
 *  dbQuery($SQL,$get_form = 'ARR')
 *    Видимость: private
 *    Входные параметры: строка - запрос к БД, строка - формат вывода
 *    Возврат: Либо массив, либо число, либо строку
 *    Действия:
 *      Подключение к базе данных.
 *      Отправка запроса к базе данных получение ответа и его обработка.
 *      Возможные значения второго параметра:
 *        ARR - вернет массив
 *        BOOLEAN - вернет 0 - если запрос не прошел, 1 - если от БД вернулся ответ
 *        EXISTS - вернет 0 - если записей не найденно, 1 - если найденна хотя бы одна запись по запросу
 *        LONELY - вернет одно поле 'rec'
 *
 *  dbUpdate($from = NULL, $data = "", $where = "")
 *    Видимость: public
 *    Входные параметры: строка - табляца для обновления, строка - поле с новым значением, строка - идентификация поля для обновления
 *    Возврат: Число
 *    Действия: вернет 0 - если запрос не прошел, 1 - если от БД вернулся ответ
 *
 *  dbInsert($from = NULL,$data = "")
 *    Видимость: public
 *    Входные параметры: строка - таблица для вставки, строка - значения
 *    Возврат: Число
 *    Действия: вернет 0 - если запрос не прошел, 1 - если от БД вернулся ответ
 *
 *  dbSELECT($fields = "",$from = "", $where = "", $order_by = "", $offset="",$limit="" )
 *    Видимость: public
 *    Входные параметры:
 *      строка - поля которые необходимо вывести
 *      строка - таблицы из которых берем данные
 *      строка - идентификация полей
 *      строка - сортировка
 *      строка - начать с элемента
 *      строка - количество выборки
 *    Возврат: Массив
 *    Действия: отправляем запрос в функцию dbQuery получаем массив и возвращаем его пользователю.
 *
 *  checkExistence( $from = "", $where = "" )
 *    Видимость: public
 *    Входные параметры: строка - таблицы из которых берем данные, строка - идентификация полей
 *    Возврат: Число
 *    Действия: вернет 0 - если записей не найденно, 1 - если найденна хотя бы одна запись по запросу
 *
 *  function countRecord( $from = "", $where = "" )
 *    Видимость: public
 *    Входные параметры: строка - таблицы из которых берем данные, строка - идентификация полей
 *    Возврат: Число
 *    Действия: Возвращает количество найденнных строк по указанному запросу.
 */

class database
{
  private $host = "localhost";
  private $login = "keygroup";
  private $password = "keygroup";
  private $dbname = "keygroup";
  private $test = 1;

  function __construct() {

  }

  private function dbQuery($SQL,$get_form = 'ARR') {
    $mysqli = new mysqli($this->host, $this->login, $this->password, $this->dbname);
    if ($mysqli->connect_errno) {
      error_log(date("Y.m.dTH:i:s",time())." :: Connect ERROR",0);
      printf("Connect ERROR: %s\n", $mysqli->connect_error);
      exit();
    }
    $mysqli->query('SET names "utf8"');
    $res = $mysqli->query($SQL);
    switch ($get_form) {
      case 'ARR':
        $arr = array();
        $i = 0;
        if( empty($res) ) { return 0; }
        while($row = mysqli_fetch_array($res, MYSQLI_ASSOC)) {
          $arr[$i] = $row;
          $i++;
        }
        $mysqli->close();
        return ($i) ? $arr : 0 ;
      case 'BOOLEAN':
        return ($res) ? 1 : 0;
      case 'EXISTS':
        $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
        return ($row['test']) ? 1 : 0;
      case 'LONELY':
        $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
        return $row['rec'];
    }
  }

  public function dbUpdate($from = NULL, $data = "", $where = "") {
    if(!empty($data) && $from != NULL) {
      $SQL = "UPDATE {$from} SET {$data}";
      if (!empty($where)) {$SQL .= " WHERE ".$where;}
      return $this->dbQuery($SQL,'BOOLEAN');
    } else {
      return 0;
    }
  }

  public function dbInsert($from = NULL,$data = "") {
    $SQL = "INSERT INTO {$from} {$data}";
    return $this->dbQuery($SQL,'BOOLEAN');
  }

  public function dbSELECT($fields = "",$from = "", $where = "", $order_by = "", $offset="",$limit="" ) {
    if(!empty($fields) && !empty($from)) {
      $SQL = "SELECT {$fields} FROM {$from}";
      if (!empty($where)) {$SQL .= " WHERE ".$where;}
      if (!empty($order_by)) {$SQL .= " ORDER BY ".$order_by;}
      if (!empty($limit)) {$SQL .= " LIMIT ".$limit;}
      if (!empty($offset)) {$SQL .= " OFFSET ".$offset;}
      return $this->dbQuery($SQL);
    } else {
      return 0;
    }
  }

  public function checkExistence( $from = "", $where = "" ) {
    if(!empty($from)) {
      $SQL = "SELECT * FROM {$from}";
      if (!empty($where)) {$SQL .= " WHERE ".$where;}
      $SQL = "SELECT EXISTS({$SQL}) AS test";
      return $this->dbQuery($SQL,'EXISTS');
    } else {
      return 0;
    }
  }

  public function countRecord( $from = "", $where = "" ) {
    if(!empty($from)) {
      $SQL = "SELECT COUNT(*) as rec FROM {$from}";
      if (!empty($where)) {$SQL .= " WHERE ".$where;}
      return $this->dbQuery($SQL,'LONELY');
    } else {
      return 0;
    }
  }
}