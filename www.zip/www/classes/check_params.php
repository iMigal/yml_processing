<?php
/**
 * Class check_params
 * Данный класс используеется для проверки различных параметров или их удаления.
 *
 *
 * В классе представленны методы:
 *
 *  drop_simbols_get($str = '')
 *    Видимость: public
 *    Входные параметры: строка
 *    Возврат: Строку
 *    Действия: Удаляет опасные символы
 *
 *  drop_simbols_in_href_get($str = '')
 *    Видимость: public
 *    Входные параметры: строка
 *    Возврат:Строку
 *    Действия: Удаляет опасные символы из ссылок
 *
 *  only_numbers_get($str = '')
 *    Видимость: public
 *    Входные параметры: строка
 *    Возврат: число
 *    Действия: удаляет все символы кроме чисел
 *
 *  check_numbers($str = '')
 *    Видимость: public
 *    Входные параметры: строка
 *    Возврат: Число
 *    Действия: Возвращает только 0 или 1.
 *      0 - если обноруженно что-то кроме числа. 1 - если это число.
 *
 *  check_param($str = '')
 *    Видимость: public
 *    Входные параметры: строка
 *    Возврат: число
 *    Действия: Возвращает только 0 или 1.
 *      0 - если в строке обноруженны опасные символы. 1 - если опасные символы в строке не обнаруженны.
 *
 *  check_arr($arr = array())
 *    Видимость: public
 *    Входные параметры: массив
 *    Возврат: число
 *    Действия:Возвращает только 0 или 1.
 *      0 - если в строке обноруженны опасные символы. 1 - если опасные символы в строке не обнаруженны.
 */

class check_params
{
  private $drop_simbols = array('#','$','&','{','}','[',']','"','\\','~');
  private $drop_simbols_in_href = array('#','$','{','}','[',']','"',"'",'\\','~');

  public function drop_simbols_get($str = '') {
    if(!empty($str)) {
      return str_ireplace($this -> drop_simbols,'',$str);
    } else {
      return 0;
    }
  }

  public function drop_simbols_in_href_get($str = '') {
    if(!empty($str)) {
      return str_ireplace($this -> drop_simbols_in_href,'',$str);
    } else {
      return 0;
    }
  }

  public function only_numbers_get($str = '') {
    if(!empty($str)) {
      return preg_replace('/[^0-9]/', '', $str);
    } else {
      return 0;
    }
  }

  public function check_numbers($str = '') {
    if(!empty($str)) {
      return (strlen($str) == strlen($str*1)) ? 1 : 0 ;
    } else {
      return 0;
    }
  }

  public function check_param($str = '') {
    if(!empty($str)) {
      return (strlen($str) === strlen(str_ireplace($this -> drop_simbols,'',$str))) ? 1 : 0 ;
    } else {
      return 0;
    }
  }

  public function check_arr($arr = array()) {
    if(!empty($arr)) {
      $result = 1;
      foreach ($arr as $key => $item) {
        if( (strlen($item) != strlen(str_ireplace($this -> drop_simbols,'',$item))) ||
          (strlen($key) != strlen(str_ireplace($this -> drop_simbols,'',$key))) )
        {
          $result = 0;
          break;
        }
      }
      return $result ;
    } else {
      return 0;
    }
  }
}