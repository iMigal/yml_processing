<?php
/**
 * Фуникции:
 *
 * breakArray2x($data)
 *    Входные параметры: Строка
 *    Возврат: Массив
 *    Действия: Разбивает строку на массив. Используется для оброботки поля ARR, таблицы ITEMS из БД
 */
  function breakArray2x($data) {
    $data = str_replace(array("[","]"),"",$data);
    $arr = explode(",", $data);
    $arr1 = array(); $result = array();
    foreach($arr as $item) {
      $arr1 = explode(":", $item);
      $result[$arr1[0]] = $arr1[1];
    }
    return $result;
  }